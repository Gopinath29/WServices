﻿//.Net Reference
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel.Description;
using System.Collections.ObjectModel;

// CRM Reference
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;

//Powershell Reference
using System.Management.Automation;
using System.Management.Automation.Host;
using System.Management.Automation.Provider;
using System.Management.Automation.Runspaces;


namespace UpdateCRMfromAD
{
    class UpdateCRMUsersfromAD : IOException
    {
        static void Main(string[] args)
        {
            // a method to retrieve active users from CRM
            RetrieveUser();
        }

        public static void RetrieveUser()
        {
           
            // Create connection with CRM
            OrganizationServiceProxy service = CreateOrganizationProxy();

            // Query CRM to retrieve active users
            QueryExpression query = new QueryExpression
            {
                EntityName = "systemuser",
                ColumnSet = new ColumnSet("fullname", "domainname", "accessmode", "systemuserid", "title")
            };
            query.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, "0");

            EntityCollection results = service.RetrieveMultiple(query);
            
            foreach (var user in results.Entities)
            {
                if (user.Attributes.Contains("domainname"))
                {
                    try
                    {
                        string[] username = { };
                        // Get the domainname and split it 
                        string domainname = Convert.ToString(user["domainname"]);
                        username = domainname.Split('\\');

                        
                        string z = "Get-Aduser -identity" + " " + username[1]+" -properties *";
                        PowerShell powershell = PowerShell.Create().AddScript(@"import-module ActiveDirectory").AddScript(z);
                        Collection<PSObject> commandResults = powershell.Invoke();

                        if (commandResults.Count != 0)
                        {
                            foreach (PSObject cmdlet in commandResults)
                            {

                                //Get the data from AD
                                bool enabled = (bool)cmdlet.Properties["Enabled"].Value;
                                string DIVISION = (string)cmdlet.Properties["extensionAttribute7"].Value;
                                string BUSINESS_UNIT = (string)cmdlet.Properties["extensionAttribute13"].Value;
                                string SUB_FUNCTION = (string)cmdlet.Properties["extensionAttribute8"].Value;
                                string COUNTRY = (string)cmdlet.Properties["Country"].Value;
                                string HFM_CODE = (string)cmdlet.Properties["extensionAttribute10"].Value;
                                string HFM_DECRIPTION = (string)cmdlet.Properties["extensionAttribute3"].Value;
                                string LOCATION_CODE_ORG = (string)cmdlet.Properties["l"].Value;
                                string MANAGER = (string)cmdlet.Properties["Manager"].Value;


                                //Update the user details in CRM
                                Entity updateUser = new Entity("systemuser");
                                updateUser.Id = user.Id;
                                updateUser["new_division"] = DIVISION;
                                updateUser["new_flsbusinessunit"] = BUSINESS_UNIT;
                                updateUser["new_subfunction"] = SUB_FUNCTION;
                                updateUser["new_country"] = COUNTRY;
                                updateUser["new_legalcompanycode"] = Convert.ToInt32(HFM_CODE);
                                updateUser["new_legalcompanydescription"] = HFM_DECRIPTION;
                                updateUser["new_location"] = LOCATION_CODE_ORG;
                                updateUser["new_hrdatalastupdatedon"] = DateTime.Now;
                                service.Update(updateUser);

                               
                            }
                        }
                      
                    }

                    catch (Exception e)
                    {
                        throw new Exception(e.Message);
                    }
                }

            }
        }

        public static OrganizationServiceProxy CreateOrganizationProxy()
        {
            try
            {
                //string userName = "CRMadmin";
                //string domain = "FLS";
                //string password = "Av@t@r3d";
                //string crmUrl = "http://cph-crm-app02-d/FLSmidthDevelopment";
                string userName = "AdminCRM6-P-IN";
                string domain = "FLS";
                string password = "CRMfl$@123";
                string crmUrl = "http://cph-crm-app01-p/FLSmidthProduction";
                bool isADFS = false;
                Uri organisationUri = new Uri(String.Format("{0}/XRMServices/2011/Organization.svc", crmUrl));
                ClientCredentials clientCredentials = new ClientCredentials();
                if (isADFS)
                {
                    clientCredentials.UserName.UserName = userName;
                    clientCredentials.UserName.Password = password;
                }
                else
                {
                    clientCredentials.Windows.ClientCredential = new System.Net.NetworkCredential(userName, password, domain);
                }
                OrganizationServiceProxy _serviceProxy = new OrganizationServiceProxy(organisationUri, null, clientCredentials, null);
                _serviceProxy.ServiceConfiguration.CurrentServiceEndpoint.Behaviors.Add(new ProxyTypesBehavior());
                _serviceProxy.Timeout = new TimeSpan(0, 10, 0);
                return _serviceProxy;
            }
            catch { throw; }
        }
    }
}

